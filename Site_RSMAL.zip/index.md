---
title: Welcome to my website

---

<p> eeAAAeeRiczalheiro is a PhD from the University of Coimbra. He concluded, in the same University, his Master and Bachelor <p>(Licenciatura - 5 years) degrees, respectively in Informatics Engineering and Mathematics (branch of Computer Graphics). He is a member of the Cognitive and Media Systems research group at the Center for Informatics and Systems of the University of Coimbra (CISUC). His main research interests and main projects are in the areas of Natural Language Processing, Detection of Emotions in Music Lyrics and Text and Text/Data Mining. He teaches at Polytechnic Institute of Leiria (IPLeiria - ESTG), Department of Informatics. Currently, he is teaching Decision Support Systems (Bach. in Informatics Engineering), Knowledge Engineering (Bach. in Informatics Engineering), Data Mining (MSc in Data Science), Text Mining (MSc in Data Science) and Software Engineering (Bach. in Informatics Engineering). He supervises several students of PhD, MSc and Bachelor degrees.33
